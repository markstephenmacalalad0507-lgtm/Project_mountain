package ui;

import service.WeatherService;

import javax.swing.*;
import javax.swing.Timer;

public class WeatherFrame extends BaseFrame {

    private JTextArea txtWeather;

    public WeatherFrame() {

        setTitle("Weather Dashboard");
        setSize(700, 400);
        setLayout(null);
        setLocationRelativeTo(null);

        txtWeather = new JTextArea();
        txtWeather.setEditable(false);

        JScrollPane scrollPane =
                new JScrollPane(txtWeather);

        scrollPane.setBounds(
                20,
                20,
                640,
                300);

        add(scrollPane);

        txtWeather.setText(
                "Loading weather data...");

        loadWeather();

        Timer timer =
                new Timer(
                        60000,
                        e -> loadWeather());

        timer.start();
        
        
        
        
    }

    private void loadWeather() {

        SwingWorker<String, Void> worker =
                new SwingWorker<String, Void>() {

                    @Override
                    protected String doInBackground()
                            throws Exception {

                        WeatherService service =
                                new WeatherService();

                        double tempValue =
                                service.getTemperature();

                        String status =
                                service.getSafetyStatus(
                                        tempValue);

                        String recommendation =
                                service.getRecommendation(
                                        tempValue);

                        return

                            "=================================\n" +

                            "     CLIMAHIKE WEATHER DASHBOARD\n" +

                            "=================================\n\n" +

                            "Location : Batangas, Philippines\n\n" +

                            "Current Temperature : "
                            + tempValue
                            + " °C\n\n" +

                            "Weather Status : "
                            + status
                            + "\n\n" +

                            "Recommendation :\n\n"
                            + recommendation
                            + "\n\n" +

                            "Data Source : Open-Meteo API\n" +

                            "Weather Data : Live Feed\n\n" +

                            "Last Updated : "
                            + java.time.LocalDateTime.now();
                    }

                    @Override
                    protected void done() {

                        try {

                            txtWeather.setText(
                                    get());

                        } catch (Exception e) {

                            txtWeather.setText(
                                "Unable to retrieve weather data.");
                        }
                    }
                };

        worker.execute();
    }
}