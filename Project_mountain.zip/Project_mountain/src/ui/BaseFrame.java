package ui;

import javax.swing.*;
import java.awt.*;

public class BaseFrame extends JFrame {

    public BaseFrame() {

        ImageIcon icon =
                new ImageIcon(
                        getClass().getResource(
                                "/images/climahike.png"));

        setIconImage(
                icon.getImage());
    }
}