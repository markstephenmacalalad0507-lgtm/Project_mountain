package ui;

import dao.TouristDAO;
import model.Tourist;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegisterTouristFrame extends BaseFrame {

    private JTextField txtBirthCode;
    private JTextField txtFullName;
    private JTextField txtAddress;
    private JTextField txtContact;

    private JComboBox<String> cmbTrail;
    private JComboBox<String> cmbGender;

    private JButton btnSave;
    private JButton btnClear;

    public RegisterTouristFrame() {

        setTitle("Register Tourist");
        setSize(500, 450);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblBirthCode = new JLabel("Birth Code:");
        lblBirthCode.setBounds(30, 30, 100, 25);
        add(lblBirthCode);

        txtBirthCode = new JTextField();
        txtBirthCode.setBounds(150, 30, 250, 25);
        add(txtBirthCode);

        JLabel lblFullName = new JLabel("Full Name:");
        lblFullName.setBounds(30, 70, 100, 25);
        add(lblFullName);

        txtFullName = new JTextField();
        txtFullName.setBounds(150, 70, 250, 25);
        add(txtFullName);

        JLabel lblAddress = new JLabel("Address:");
        lblAddress.setBounds(30, 110, 100, 25);
        add(lblAddress);

        txtAddress = new JTextField();
        txtAddress.setBounds(150, 110, 250, 25);
        add(txtAddress);

        JLabel lblContact = new JLabel("Contact:");
        lblContact.setBounds(30, 150, 100, 25);
        add(lblContact);

        txtContact = new JTextField();
        txtContact.setBounds(150, 150, 250, 25);
        add(txtContact);

        JLabel lblTrail = new JLabel("Trail:");
        lblTrail.setBounds(30, 190, 100, 25);
        add(lblTrail);

        cmbTrail = new JComboBox<>();
        cmbTrail.addItem("Beginner");
        cmbTrail.addItem("Intermediate");
        cmbTrail.addItem("Advanced");
        cmbTrail.setBounds(150, 190, 250, 25);
        add(cmbTrail);

        JLabel lblGender = new JLabel("Gender:");
        lblGender.setBounds(30, 230, 100, 25);
        add(lblGender);

        cmbGender = new JComboBox<>();
        cmbGender.addItem("Male");
        cmbGender.addItem("Female");
        cmbGender.setBounds(150, 230, 250, 25);
        add(cmbGender);

        btnSave = new JButton("Save");
        btnSave.setBounds(150, 300, 100, 35);
        add(btnSave);

        btnClear = new JButton("Clear");
        btnClear.setBounds(270, 300, 100, 35);
        add(btnClear);

        btnSave.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                try {

                    Tourist tourist = new Tourist();

                    tourist.setBirthCode(txtBirthCode.getText());
                    tourist.setFullName(txtFullName.getText());
                    tourist.setAddress(txtAddress.getText());
                    tourist.setContact(txtContact.getText());

                    tourist.setTrail(
                            cmbTrail.getSelectedItem().toString());

                    tourist.setGender(
                            cmbGender.getSelectedItem().toString());

                    tourist.setTimeIn(
                            java.time.LocalDateTime.now().toString());

                    tourist.setTimeOut("");

                    TouristDAO dao = new TouristDAO();
                    dao.insertTourist(tourist);

                    JOptionPane.showMessageDialog(
                            null,
                            "Tourist Registered Successfully!");

                } catch (Exception ex) {

                    JOptionPane.showMessageDialog(
                            null,
                            ex.getMessage());

                    ex.printStackTrace();
                }
            }
        });

        btnClear.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                txtBirthCode.setText("");
                txtFullName.setText("");
                txtAddress.setText("");
                txtContact.setText("");

                cmbTrail.setSelectedIndex(0);
                cmbGender.setSelectedIndex(0);
            }
        });
    }
}