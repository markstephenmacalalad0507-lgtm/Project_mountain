package ui;

import dao.InjuryDAO;
import model.InjuryReport;

import javax.swing.*;

public class InjuryFormFrame extends BaseFrame {

    private JTextField txtTouristId;

    private JComboBox<String> cmbInjuryCase;

    private JButton btnSave;

    public InjuryFormFrame() {

        setTitle("Injury Monitoring");
        setSize(450, 300);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblTouristId =
                new JLabel("Tourist ID:");

        lblTouristId.setBounds(
                30, 30, 100, 25);

        add(lblTouristId);

        txtTouristId =
                new JTextField();

        txtTouristId.setBounds(
                150, 30, 200, 25);

        add(txtTouristId);

        JLabel lblCase =
                new JLabel("Injury Case:");

        lblCase.setBounds(
                30, 80, 100, 25);

        add(lblCase);

        cmbInjuryCase =
                new JComboBox<>();

        cmbInjuryCase.addItem("Minor");
        cmbInjuryCase.addItem("Moderate");
        cmbInjuryCase.addItem("Severe");

        cmbInjuryCase.setBounds(
                150, 80, 200, 25);

        add(cmbInjuryCase);

        btnSave =
                new JButton("Save Injury");

        btnSave.setBounds(
                150, 150, 150, 35);

        add(btnSave);

        btnSave.addActionListener(e -> {

            try {

                InjuryReport report =
                        new InjuryReport();

                report.setTouristId(
                        Integer.parseInt(
                                txtTouristId.getText()));

                report.setInjuryCase(
                        cmbInjuryCase
                                .getSelectedItem()
                                .toString());

                report.setInjuryDate(
                        java.time.LocalDateTime
                                .now()
                                .toString());

                InjuryDAO dao =
                        new InjuryDAO();

                dao.insertInjury(report);

                JOptionPane.showMessageDialog(
                        this,
                        "Injury Recorded Successfully!");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        ex.getMessage());

            }

        });
    }
}