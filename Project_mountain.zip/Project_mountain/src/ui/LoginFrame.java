package ui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import ui.DashboardFrame;

public class LoginFrame extends BaseFrame {

    private JLabel lblUser;
    private JLabel lblPass;

    private JTextField txtUser;
    private JPasswordField txtPass;

    private JButton btnLogin;

    public LoginFrame() {

        setTitle("ClimaHike Login");
        setSize(400,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        setResizable(false);
        setMinimumSize(new java.awt.Dimension(400, 300));

        lblUser = new JLabel("Username:");
        lblUser.setBounds(50, 50, 100, 25);

        txtUser = new JTextField();
        txtUser.setBounds(150, 50, 150, 25);

        lblPass = new JLabel("Password:");
        lblPass.setBounds(50, 100, 100, 25);

        txtPass = new JPasswordField();
        txtPass.setBounds(150, 100, 150, 25);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(150, 150, 100, 30);
        btnLogin.addActionListener(e -> {

            DashboardFrame dashboard =
                    new DashboardFrame();

            dashboard.setVisible(true);

            dispose();

        });

        add(lblUser);
        add(txtUser);
        add(lblPass);
        add(txtPass);
        add(btnLogin);
    }
}