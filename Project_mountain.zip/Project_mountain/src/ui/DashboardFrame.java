package ui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import ui.LoginFrame;
import javax.swing.JOptionPane;

public class DashboardFrame extends BaseFrame {

    private JLabel lblTitle;

    private JButton btnRegister;
    private JButton btnRecords;
    private JButton btnTracking;
    private JButton btnInjury;
    private JButton btnWeather;
    private JButton btnReports;
    private JButton btnLogout;
    

    public DashboardFrame() {

        setTitle("ClimaHike Dashboard");
        
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        lblTitle = new JLabel("CLIMAHIKE DASHBOARD");
        lblTitle.setBounds(200, 20, 250, 30);

        btnRegister = new JButton("Register Tourist");
        btnRegister.setBounds(180, 70, 220, 35);
        btnRegister.addActionListener(e -> {

            RegisterTouristFrame registerFrame =
                    new RegisterTouristFrame();

            registerFrame.setVisible(true);

        });

        btnRecords = new JButton("Tourist Records");
        btnRecords.setBounds(180, 120, 220, 35);
        btnRecords.addActionListener(e -> {

            TouristRecordsFrame recordsFrame =
                    new TouristRecordsFrame();

            recordsFrame.setVisible(true);

        });

        btnTracking = new JButton("Time Tracking");
        btnTracking.setBounds(180, 170, 220, 35);
        btnTracking.addActionListener(e -> {

            TimeTrackingFrame frame =
                    new TimeTrackingFrame();

            frame.setVisible(true);

        });

        btnInjury = new JButton("Injury Monitoring");
        btnInjury.setBounds(180, 220, 220, 35);
        btnInjury.addActionListener(e -> {

            InjuryFormFrame frame =
                    new InjuryFormFrame();

            frame.setVisible(true);

        });

        btnWeather = new JButton("Weather Dashboard");
        btnWeather.setBounds(180, 270, 220, 35);
        btnWeather.addActionListener(e -> {

            WeatherFrame frame =
                    new WeatherFrame();

            frame.setVisible(true);

        });

        btnReports = new JButton("Reports");
        btnReports.setBounds(180, 320, 220, 35);
        btnReports.addActionListener(e -> {

            ReportsFrame frame =
                    new ReportsFrame();

            frame.setVisible(true);

        });

        btnLogout = new JButton("Logout");
        btnLogout.setBounds(180, 370, 220, 35);
        btnLogout.addActionListener(e -> {

            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to logout?",
                    "Logout Confirmation",
                    JOptionPane.YES_NO_OPTION);

            if(choice == JOptionPane.YES_OPTION) {

                LoginFrame login = new LoginFrame();

                login.setVisible(true);
                JOptionPane.showMessageDialog(
                        this,
                        "Logged out successfully.");

                dispose();
            }

        });

        add(lblTitle);
        add(btnRegister);
        add(btnRecords);
        add(btnTracking);
        add(btnInjury);
        add(btnWeather);
        add(btnReports);
        add(btnLogout);
    }
}