package ui;

import dao.TouristDAO;
import model.Tourist;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.sql.ResultSet;

public class TouristRecordsFrame extends BaseFrame {

    private JTable table;
    private DefaultTableModel model;

    public TouristRecordsFrame() {

        setTitle("Tourist Records");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columns = {

        	    "ID",
        	    "Birth Code",
        	    "Full Name",
        	    "Address",
        	    "Trail",

        	    "Category 1 IN",
        	    "Category 2 IN",
        	    "Category 3 IN",

        	    "Category 3 OUT",
        	    "Category 2 OUT",
        	    "Category 1 OUT"
        	};
        
        model = new DefaultTableModel(columns, 0);

        table = new JTable(model);

        JScrollPane scrollPane =
                new JScrollPane(table);

        add(scrollPane);

        loadData();

        // AUTO REFRESH EVERY 3 SECONDS
        Timer timer = new Timer(3000, e -> {

            loadData();

        });

        timer.start();
    }

    private void loadData() {

        try {

            TouristDAO dao =
                    new TouristDAO();

            ResultSet rs =
                    dao.getTouristTracking();

            model.setRowCount(0);

            while (rs.next()) {

                model.addRow(new Object[] {

                    rs.getInt("tourist_id"),
                    rs.getString("birth_code"),
                    rs.getString("full_name"),
                    rs.getString("address"),
                    rs.getString("trail"),

                    rs.getString("category1_in"),
                    rs.getString("category2_in"),
                    rs.getString("category3_in"),

                    rs.getString("category3_out"),
                    rs.getString("category2_out"),
                    rs.getString("category1_out")
                });
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    e.getMessage());
        }
    }
}