package ui;

import dao.TrackingDAO;

import javax.swing.*;

public class TimeTrackingFrame extends BaseFrame {

    private JTextField txtTouristId;

    private JButton btnCategory1In;
    private JButton btnCategory2In;
    private JButton btnCategory3In;

    private JButton btnCategory3Out;
    private JButton btnCategory2Out;
    private JButton btnCategory1Out;

    public TimeTrackingFrame() {

        setTitle("Time Tracking");
        setSize(420, 350);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblId = new JLabel("Tourist ID:");
        lblId.setBounds(30, 30, 100, 25);
        add(lblId);

        txtTouristId = new JTextField();
        txtTouristId.setBounds(130, 30, 200, 25);
        add(txtTouristId);

        btnCategory1In = new JButton("Category 1 IN");
        btnCategory1In.setBounds(30, 80, 150, 35);
        add(btnCategory1In);

        btnCategory2In = new JButton("Category 2 IN");
        btnCategory2In.setBounds(220, 80, 150, 35);
        add(btnCategory2In);

        btnCategory3In = new JButton("Category 3 IN");
        btnCategory3In.setBounds(30, 130, 150, 35);
        add(btnCategory3In);

        btnCategory3Out = new JButton("Category 3 OUT");
        btnCategory3Out.setBounds(220, 130, 150, 35);
        add(btnCategory3Out);

        btnCategory2Out = new JButton("Category 2 OUT");
        btnCategory2Out.setBounds(30, 180, 150, 35);
        add(btnCategory2Out);

        btnCategory1Out = new JButton("Category 1 OUT");
        btnCategory1Out.setBounds(220, 180, 150, 35);
        add(btnCategory1Out);

        // CATEGORY 1 IN
        btnCategory1In.addActionListener(e -> {

            try {

                int touristId =
                        Integer.parseInt(
                                txtTouristId.getText());

                TrackingDAO dao =
                        new TrackingDAO();

                dao.recordCategory1In(touristId);

                JOptionPane.showMessageDialog(
                        this,
                        "Category 1 IN Recorded");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        ex.getMessage());
            }
        });

        // CATEGORY 2 IN
        btnCategory2In.addActionListener(e -> {

            try {

                int touristId =
                        Integer.parseInt(
                                txtTouristId.getText());

                TrackingDAO dao =
                        new TrackingDAO();

                dao.recordCategory2In(touristId);

                JOptionPane.showMessageDialog(
                        this,
                        "Category 2 IN Recorded");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        ex.getMessage());
            }
        });

        // CATEGORY 3 IN
        btnCategory3In.addActionListener(e -> {

            try {

                int touristId =
                        Integer.parseInt(
                                txtTouristId.getText());

                TrackingDAO dao =
                        new TrackingDAO();

                dao.recordCategory3In(touristId);

                JOptionPane.showMessageDialog(
                        this,
                        "Category 3 IN Recorded");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        ex.getMessage());
            }
        });

        // CATEGORY 3 OUT
        btnCategory3Out.addActionListener(e -> {

            try {

                int touristId =
                        Integer.parseInt(
                                txtTouristId.getText());

                TrackingDAO dao =
                        new TrackingDAO();

                dao.recordCategory3Out(touristId);

                JOptionPane.showMessageDialog(
                        this,
                        "Category 3 OUT Recorded");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        ex.getMessage());
            }
        });

        // CATEGORY 2 OUT
        btnCategory2Out.addActionListener(e -> {

            try {

                int touristId =
                        Integer.parseInt(
                                txtTouristId.getText());

                TrackingDAO dao =
                        new TrackingDAO();

                dao.recordCategory2Out(touristId);

                JOptionPane.showMessageDialog(
                        this,
                        "Category 2 OUT Recorded");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        ex.getMessage());
            }
        });

        // CATEGORY 1 OUT
        btnCategory1Out.addActionListener(e -> {

            try {

                int touristId =
                        Integer.parseInt(
                                txtTouristId.getText());

                TrackingDAO dao =
                        new TrackingDAO();

                dao.recordCategory1Out(touristId);

                JOptionPane.showMessageDialog(
                        this,
                        "Category 1 OUT Recorded");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        ex.getMessage());
            }
        });
    }
}