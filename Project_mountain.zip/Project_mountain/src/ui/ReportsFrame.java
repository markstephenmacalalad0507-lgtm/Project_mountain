package ui;

import reports.DailyReport;
import reports.MonthlyReport;
import reports.YearlyReport;

import javax.swing.*;

public class ReportsFrame extends BaseFrame {

    private JButton btnDaily;
    private JButton btnMonthly;
    private JButton btnYearly;

    private JTextArea txtReport;

    public ReportsFrame() {

        setTitle("Reports Module");
        setSize(600, 400);
        setLayout(null);
        setLocationRelativeTo(null);

        btnDaily = new JButton("Daily Report");
        btnDaily.setBounds(30, 30, 150, 35);
        add(btnDaily);

        btnMonthly = new JButton("Monthly Report");
        btnMonthly.setBounds(210, 30, 150, 35);
        add(btnMonthly);

        btnYearly = new JButton("Yearly Report");
        btnYearly.setBounds(390, 30, 150, 35);
        add(btnYearly);

        txtReport = new JTextArea();

        JScrollPane scrollPane =
                new JScrollPane(txtReport);

        scrollPane.setBounds(
                30,
                90,
                510,
                220);

        add(scrollPane);

        btnDaily.addActionListener(e -> {

            DailyReport report =
                    new DailyReport();

            txtReport.setText(
                    report.generateReport());
        });

        btnMonthly.addActionListener(e -> {

            MonthlyReport report =
                    new MonthlyReport();

            txtReport.setText(
                    report.generateReport());
        });

        btnYearly.addActionListener(e -> {

            YearlyReport report =
                    new YearlyReport();

            txtReport.setText(
                    report.generateReport());
        });
    }
}