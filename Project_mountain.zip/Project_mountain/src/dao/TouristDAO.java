package dao;

import model.Tourist;
import database.MySQLConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

public class TouristDAO {

    // === Insert Tourist ===
    public void insertTourist(Tourist t) throws SQLException {
        String sql = "INSERT INTO tourists (birth_code, full_name, address, contact, trail, gender, time_in, time_out) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = MySQLConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getBirthCode());
            ps.setString(2, t.getFullName());
            ps.setString(3, t.getAddress());
            ps.setString(4, t.getContact());
            ps.setString(5, t.getTrail());
            ps.setString(6, t.getGender());
            ps.setString(7, t.getTimeIn());
            ps.setString(8, t.getTimeOut());
            ps.executeUpdate();
        }
    }

    // === Get All Tourists ===
    public List<Tourist> getAllTourists() throws SQLException {
        List<Tourist> list = new ArrayList<>();
        String sql = "SELECT * FROM tourists";
        try (Connection conn = MySQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Tourist t = new Tourist();
                t.setTouristId(rs.getInt("tourist_id"));
                t.setBirthCode(rs.getString("birth_code"));
                t.setFullName(rs.getString("full_name"));
                t.setAddress(rs.getString("address"));
                t.setContact(rs.getString("contact"));
                t.setTrail(rs.getString("trail"));
                t.setGender(rs.getString("gender"));
                t.setTimeIn(rs.getString("time_in"));
                t.setTimeOut(rs.getString("time_out"));
                list.add(t);
            }
        }
        return list;
    }

    // === Update Tourist ===
    public void updateTourist(Tourist t) throws SQLException {
        String sql = "UPDATE tourists SET full_name=?, address=?, contact=?, trail=?, gender=? WHERE birth_code=?";
        try (Connection conn = MySQLConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getFullName());
            ps.setString(2, t.getAddress());
            ps.setString(3, t.getContact());
            ps.setString(4, t.getTrail());
            ps.setString(5, t.getGender());
            ps.setString(6, t.getBirthCode());
            ps.executeUpdate();
        }
    }

    // === Delete Tourist ===
    public void deleteTourist(int touristId)
            throws SQLException {

        String sql =
            "DELETE FROM tourists WHERE tourist_id=?";

        try (Connection conn =
                     MySQLConnection.getConnection();

             PreparedStatement ps =
                     conn.prepareStatement(sql)) {

            ps.setInt(1, touristId);

            ps.executeUpdate();
        }
    }

    // === Records Per Day ===
    public Map<String, Integer> getTouristsPerDay() throws SQLException {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT DATE(time_in) AS day, COUNT(*) AS total FROM tourists GROUP BY DATE(time_in)";
        try (Connection conn = MySQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                map.put(rs.getString("day"), rs.getInt("total"));
            }
        }
        return map;
    }

    // === Records Per Month ===
    public Map<String, Integer> getTouristsPerMonth()
            throws SQLException {

        Map<String, Integer> map =
                new LinkedHashMap<>();

        String sql =
            "SELECT DATE_FORMAT(time_in,'%M') AS month, " +
            "COUNT(*) AS total " +
            "FROM tourists " +
            "GROUP BY DATE_FORMAT(time_in,'%M')";

        try (Connection conn =
                     MySQLConnection.getConnection();

             Statement stmt =
                     conn.createStatement();

             ResultSet rs =
                     stmt.executeQuery(sql)) {

            while (rs.next()) {

                map.put(
                        rs.getString("month"),
                        rs.getInt("total"));
            }
        }

        return map;
    }

    // === Records Per Year ===
    public Map<String, Integer> getTouristsPerYear()
            throws SQLException {

        Map<String, Integer> map =
                new LinkedHashMap<>();

        String sql =
            "SELECT YEAR(time_in) AS year, " +
            "COUNT(*) AS total " +
            "FROM tourists " +
            "GROUP BY YEAR(time_in)";

        try (Connection conn =
                     MySQLConnection.getConnection();

             Statement stmt =
                     conn.createStatement();

             ResultSet rs =
                     stmt.executeQuery(sql)) {

            while (rs.next()) {

                map.put(
                        rs.getString("year"),
                        rs.getInt("total"));
            }
        }

        return map;
    }
    
 // === Search Tourist ===
    public List<Tourist> searchTourist(String keyword)
            throws SQLException {

        List<Tourist> list = new ArrayList<>();

        String sql =
            "SELECT * FROM tourists " +
            "WHERE full_name LIKE ? " +
            "OR birth_code LIKE ?";

        try (Connection conn =
                     MySQLConnection.getConnection();

             PreparedStatement ps =
                     conn.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Tourist t = new Tourist();

                t.setTouristId(
                        rs.getInt("tourist_id"));

                t.setBirthCode(
                        rs.getString("birth_code"));

                t.setFullName(
                        rs.getString("full_name"));

                t.setAddress(
                        rs.getString("address"));

                t.setContact(
                        rs.getString("contact"));

                t.setTrail(
                        rs.getString("trail"));

                t.setGender(
                        rs.getString("gender"));

                t.setTimeIn(
                        rs.getString("time_in"));

                t.setTimeOut(
                        rs.getString("time_out"));

                list.add(t);
            }
        }

        return list;
    }
    
 // === Get Tourists with Tracking ===
    public ResultSet getTouristTracking()
            throws SQLException {

        String sql =

            "SELECT " +
            "t.tourist_id, " +
            "t.birth_code, " +
            "t.full_name, " +
            "t.address, " +
            "t.trail, " +

            "tr.category1_in, " +
            "tr.category2_in, " +
            "tr.category3_in, " +

            "tr.category3_out, " +
            "tr.category2_out, " +
            "tr.category1_out " +

            "FROM tourists t " +

            "LEFT JOIN tracking tr " +
            "ON t.tourist_id = tr.tourist_id";

        Connection conn =
                MySQLConnection.getConnection();

        PreparedStatement ps =
                conn.prepareStatement(sql);

        return ps.executeQuery();
    }

 // === Count Tourists ===
    public int countTourists() throws SQLException {

        String sql = "SELECT COUNT(*) FROM tourists";

        try (Connection conn = MySQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        }

        return 0;
        
        
    }
    
}
