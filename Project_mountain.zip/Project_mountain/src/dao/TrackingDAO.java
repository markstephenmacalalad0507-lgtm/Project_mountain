package dao;

import database.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.LocalDateTime;

public class TrackingDAO {
	private LocalDateTime getPhilippineTime() {

	    return ZonedDateTime.now(
	            ZoneId.of("Asia/Manila"))
	            .toLocalDateTime();
	}

	public void recordCategory1In(int touristId)
	        throws Exception {

	    String checkSql =
	            "SELECT tourist_id " +
	            "FROM tracking " +
	            "WHERE tourist_id=?";

	    Connection conn =
	            MySQLConnection.getConnection();

	    PreparedStatement checkPs =
	            conn.prepareStatement(checkSql);

	    checkPs.setInt(1, touristId);

	    ResultSet rs =
	            checkPs.executeQuery();

	    if (rs.next()) {

	        String updateSql =
	                "UPDATE tracking " +
	                "SET category1_in=? " +
	                "WHERE tourist_id=?";

	        PreparedStatement updatePs =
	                conn.prepareStatement(updateSql);

	        updatePs.setObject(
	                1,
	                getPhilippineTime());

	        updatePs.setInt(
	                2,
	                touristId);

	        updatePs.executeUpdate();

	        updatePs.close();

	    } else {

	        String insertSql =
	                "INSERT INTO tracking " +
	                "(tourist_id, category1_in) " +
	                "VALUES (?, ?)";

	        PreparedStatement insertPs =
	                conn.prepareStatement(insertSql);

	        insertPs.setInt(
	                1,
	                touristId);

	        insertPs.setObject(
	                2,
	                getPhilippineTime());

	        insertPs.executeUpdate();

	        insertPs.close();
	    }

	    rs.close();
	    checkPs.close();
	    conn.close();
	}
    public void recordCategory2In(int touristId)
            throws Exception {

        String sql =
            "UPDATE tracking " +
            "SET category2_in=? " +
            "WHERE tourist_id=?";

        Connection conn =
                MySQLConnection.getConnection();

        PreparedStatement ps =
                conn.prepareStatement(sql);

        ps.setObject(
                1,
                getPhilippineTime());

        ps.setInt(2, touristId);

        ps.executeUpdate();

        ps.close();
        conn.close();
    }
    
    public void recordCategory3In(int touristId)
            throws Exception {

        String sql =
            "UPDATE tracking " +
            "SET category3_in=? " +
            "WHERE tourist_id=?";

        Connection conn =
                MySQLConnection.getConnection();

        PreparedStatement ps =
                conn.prepareStatement(sql);

        ps.setObject(
                1,
                getPhilippineTime());

        ps.setInt(2, touristId);

        ps.executeUpdate();

        ps.close();
        conn.close();
    }
    
    public void recordCategory3Out(int touristId)
            throws Exception {

        String sql =
            "UPDATE tracking " +
            "SET category3_out=? " +
            "WHERE tourist_id=?";

        Connection conn =
                MySQLConnection.getConnection();

        PreparedStatement ps =
                conn.prepareStatement(sql);

        ps.setObject(
                1,
                getPhilippineTime());

        ps.setInt(2, touristId);

        ps.executeUpdate();

        ps.close();
        conn.close();
    }
    
    public void recordCategory2Out(int touristId)
            throws Exception {

        String sql =
            "UPDATE tracking " +
            "SET category2_out=? " +
            "WHERE tourist_id=?";

        Connection conn =
                MySQLConnection.getConnection();

        PreparedStatement ps =
                conn.prepareStatement(sql);

        ps.setObject(
                1,
                getPhilippineTime());

        ps.setInt(2, touristId);

        ps.executeUpdate();

        ps.close();
        conn.close();
    }
    
    public void recordCategory1Out(int touristId)
            throws Exception {

        String sql =
            "UPDATE tracking " +
            "SET category1_out=? " +
            "WHERE tourist_id=?";

        Connection conn =
                MySQLConnection.getConnection();

        PreparedStatement ps =
                conn.prepareStatement(sql);

        ps.setObject(
                1,
                getPhilippineTime());

        ps.setInt(2, touristId);

        ps.executeUpdate();

        ps.close();
        conn.close();
    }
    
 // === Count Tracking Records ===
    public int countTrackingRecords() throws Exception {

        String sql =
                "SELECT COUNT(*) FROM tracking";

        Connection conn =
                MySQLConnection.getConnection();

        Statement stmt =
                conn.createStatement();

        ResultSet rs =
                stmt.executeQuery(sql);

        int total = 0;

        if (rs.next()) {

            total = rs.getInt(1);
        }

        rs.close();
        stmt.close();
        conn.close();

        return total;
    }
}

