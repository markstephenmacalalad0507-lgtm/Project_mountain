package dao;

import model.InjuryReport;
import database.MySQLConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

public class InjuryDAO {

    // === Insert new injury report ===
    public void insertInjury(InjuryReport ir) throws SQLException {
        String sql = "INSERT INTO injury_reports (tourist_id, injury_case, injury_date) VALUES (?, ?, ?)";
        try (Connection conn = MySQLConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, ir.getTouristId());
            ps.setString(2, ir.getInjuryCase());
            ps.setString(3, ir.getInjuryDate());
            ps.executeUpdate();
        }
    }

    // === Get all injury reports ===
    public List<InjuryReport> getAllInjuries() throws SQLException {
        List<InjuryReport> list = new ArrayList<>();
        String sql = "SELECT * FROM injury_reports";
        try (Connection conn = MySQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                InjuryReport ir = new InjuryReport();
                ir.setInjuryId(rs.getInt("injury_id"));
                ir.setTouristId(rs.getInt("tourist_id"));
                ir.setInjuryCase(rs.getString("injury_case"));
                ir.setInjuryDate(rs.getString("injury_date"));
                list.add(ir);
            }
        }
        return list;
    }

    // === Injuries Per Day ===
    public Map<String, Integer> getInjuriesPerDay() throws SQLException {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT DATE(injury_date) AS day, COUNT(*) AS total FROM injury_reports GROUP BY DATE(injury_date)";
        try (Connection conn = MySQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                map.put(rs.getString("day"), rs.getInt("total"));
            }
        }
        return map;
    }

    // === Injuries Per Month ===
    public Map<String, Integer> getInjuriesPerMonth()
            throws SQLException {

        Map<String, Integer> map =
                new LinkedHashMap<>();

        String sql =
            "SELECT DATE_FORMAT(injury_date,'%M') AS month, " +
            "COUNT(*) AS total " +
            "FROM injury_reports " +
            "GROUP BY DATE_FORMAT(injury_date,'%M')";

        try (Connection conn =
                     MySQLConnection.getConnection();

             Statement stmt =
                     conn.createStatement();

             ResultSet rs =
                     stmt.executeQuery(sql)) {

            while (rs.next()) {

                map.put(
                        rs.getString("month"),
                        rs.getInt("total"));
            }
        }

        return map;
    }

    // === Injuries Per Year ===
    public Map<String, Integer> getInjuriesPerYear() throws SQLException {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT YEAR(injury_date) AS year, COUNT(*) AS total FROM injury_reports GROUP BY YEAR(injury_date)";
        try (Connection conn = MySQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                map.put(rs.getString("year"), rs.getInt("total"));
            }
        }
        return map;
    }
    
 // === Count Injuries ===
    public int countInjuries() throws SQLException {

        String sql =
                "SELECT COUNT(*) FROM injury_reports";

        try (Connection conn =
                     MySQLConnection.getConnection();

             Statement stmt =
                     conn.createStatement();

             ResultSet rs =
                     stmt.executeQuery(sql)) {

            if (rs.next()) {

                return rs.getInt(1);
            }
        }

        return 0;
    }
}
