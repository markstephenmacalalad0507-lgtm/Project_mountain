package reports;

import dao.TouristDAO;
import dao.InjuryDAO;

import java.util.Map;

public class MonthlyReport extends Report {

    public MonthlyReport() {

        reportType = "Monthly Report";
    }

    @Override
    public String generateReport() {

        try {

            TouristDAO touristDAO =
                    new TouristDAO();

            InjuryDAO injuryDAO =
                    new InjuryDAO();

            StringBuilder report =
                    new StringBuilder();

            report.append(
                    "\t\t===== MONTHLY REPORT =====\n\n");

            report.append(
                    "Tourists Per Month\n\n");

            Map<String,Integer> tourists =
                    touristDAO.getTouristsPerMonth();

            for(String month : tourists.keySet()) {

                report.append(
                        month)
                        .append(" : ")
                        .append(
                                tourists.get(month))
                        .append("\n");
            }

            report.append(
                    "\nInjuries Per Month\n\n");

            Map<String,Integer> injuries =
                    injuryDAO.getInjuriesPerMonth();

            for(String month : injuries.keySet()) {

                report.append(
                        month)
                        .append(" : ")
                        .append(
                                injuries.get(month))
                        .append("\n");
            }

            return report.toString();

        }

        catch(Exception e) {

            return e.getMessage();
        }
    }
}