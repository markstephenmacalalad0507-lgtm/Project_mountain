package reports;

import dao.TouristDAO;
import dao.InjuryDAO;
import dao.TrackingDAO;

public class DailyReport extends Report {

    public DailyReport() {

        reportType = "Daily Report";
    }

    @Override
    public String generateReport() {

        try {

            TouristDAO touristDAO =
                    new TouristDAO();

            InjuryDAO injuryDAO =
                    new InjuryDAO();

            TrackingDAO trackingDAO =
                    new TrackingDAO();

            int tourists =
                    touristDAO.countTourists();

            int injuries =
                    injuryDAO.countInjuries();

            int tracking =
                    trackingDAO.countTrackingRecords();

            return
                "\t\t================================\n" +
                "      \t\t\tCLIMAHIKE DAILY REPORT\n" +
                "\t\t=================================\n\n" +

                "Total Registered Tourists : "
                + tourists +

                "\n\nTotal Tracking Records : "
                + tracking +

                "\n\nTotal Injury Cases : "
                + injuries +

                "\n\nWeather Status : SAFE FOR HIKING" +

                "\n\nReport Generated Successfully.";

        }

        catch (Exception e) {

            return
                "Error Generating Report\n\n"
                + e.getMessage();
        }
    }
}