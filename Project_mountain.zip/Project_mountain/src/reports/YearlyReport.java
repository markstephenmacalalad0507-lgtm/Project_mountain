package reports;

import dao.TouristDAO;
import dao.InjuryDAO;

import java.util.Map;

public class YearlyReport extends Report {

    public YearlyReport() {

        reportType = "Yearly Report";
    }

    @Override
    public String generateReport() {

        try {

            TouristDAO touristDAO =
                    new TouristDAO();

            InjuryDAO injuryDAO =
                    new InjuryDAO();

            StringBuilder report =
                    new StringBuilder();

            report.append(
                    "\t\t===== YEARLY REPORT =====\n\n");

            report.append(
                    "Tourists Per Year\n\n");

            Map<String,Integer> tourists =
                    touristDAO.getTouristsPerYear();

            for(String year : tourists.keySet()) {

                report.append(year)
                      .append(" : ")
                      .append(tourists.get(year))
                      .append("\n");
            }

            report.append(
                    "\nInjuries Per Year\n\n");

            Map<String,Integer> injuries =
                    injuryDAO.getInjuriesPerYear();

            for(String year : injuries.keySet()) {

                report.append(year)
                      .append(" : ")
                      .append(injuries.get(year))
                      .append("\n");
            }

            return report.toString();

        }

        catch(Exception e) {

            return
                "Error Generating Report\n\n"
                + e.getMessage();
        }
    }
}