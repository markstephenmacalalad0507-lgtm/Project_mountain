package reports;

public abstract class Report {

    protected String reportType;

    public String getReportType() {
        return reportType;
    }

    public abstract String generateReport();
}