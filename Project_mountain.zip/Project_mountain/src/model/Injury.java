package model;

public class Injury {

    private int injuryId;
    private int touristId;

    private String category;
    private String injuryDetails;
    private String injuryDate;

    public int getInjuryId() {
        return injuryId;
    }

    public void setInjuryId(int injuryId) {
        this.injuryId = injuryId;
    }

    public int getTouristId() {
        return touristId;
    }

    public void setTouristId(int touristId) {
        this.touristId = touristId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getInjuryDetails() {
        return injuryDetails;
    }

    public void setInjuryDetails(String injuryDetails) {
        this.injuryDetails = injuryDetails;
    }

    public String getInjuryDate() {
        return injuryDate;
    }

    public void setInjuryDate(String injuryDate) {
        this.injuryDate = injuryDate;
    }
}