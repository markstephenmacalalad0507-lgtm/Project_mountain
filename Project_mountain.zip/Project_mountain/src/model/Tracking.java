package model;

public class Tracking {

    private int trackingId;
    private int touristId;

    private String category1In;
    private String category2In;
    private String category3In;

    private String category3Out;
    private String category2Out;
    private String category1Out;

    public int getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(int trackingId) {
        this.trackingId = trackingId;
    }

    public int getTouristId() {
        return touristId;
    }

    public void setTouristId(int touristId) {
        this.touristId = touristId;
    }

    public String getCategory1In() {
        return category1In;
    }

    public void setCategory1In(String category1In) {
        this.category1In = category1In;
    }

    public String getCategory2In() {
        return category2In;
    }

    public void setCategory2In(String category2In) {
        this.category2In = category2In;
    }

    public String getCategory3In() {
        return category3In;
    }

    public void setCategory3In(String category3In) {
        this.category3In = category3In;
    }

    public String getCategory3Out() {
        return category3Out;
    }

    public void setCategory3Out(String category3Out) {
        this.category3Out = category3Out;
    }

    public String getCategory2Out() {
        return category2Out;
    }

    public void setCategory2Out(String category2Out) {
        this.category2Out = category2Out;
    }

    public String getCategory1Out() {
        return category1Out;
    }

    public void setCategory1Out(String category1Out) {
        this.category1Out = category1Out;
    }
}