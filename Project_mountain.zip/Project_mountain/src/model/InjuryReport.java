package model;

public class InjuryReport {
    private int injuryId;
    private int touristId;
    private String injuryCase;
    private String injuryDate;

    // Getters & Setters
    public int getInjuryId() { return injuryId; }
    public void setInjuryId(int injuryId) { this.injuryId = injuryId; }

    public int getTouristId() { return touristId; }
    public void setTouristId(int touristId) { this.touristId = touristId; }

    public String getInjuryCase() { return injuryCase; }
    public void setInjuryCase(String injuryCase) { this.injuryCase = injuryCase; }

    public String getInjuryDate() { return injuryDate; }
    public void setInjuryDate(String injuryDate) { this.injuryDate = injuryDate; }
}
