package database;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySQLConnection {

    public static Connection getConnection() {

        try {

            return DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/climahike",
                    "root",
                    "root123"
            );

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}