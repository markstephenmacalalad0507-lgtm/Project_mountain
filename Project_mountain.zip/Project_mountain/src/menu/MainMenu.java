package menu;

import dao.TouristDAO;
import dao.InjuryDAO;
import model.Tourist;
import model.InjuryReport;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainMenu {
    private static final Scanner sc = new Scanner(System.in);
    private static final TouristDAO dao = new TouristDAO();
    private static final InjuryDAO injuryDao = new InjuryDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== Tambol Hill System ===");
            System.out.println("1. Register Tourist");
            System.out.println("2. View All Tourists");
            System.out.println("3. Update Tourist");
            System.out.println("4. Record Injury");
            System.out.println("5. View Injuries");
            System.out.println("6. Reports Menu");
            System.out.println("7. Exit ");
            System.out.print("Choice: ");
            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> registerTourist();
                case "2" -> viewTourists();
                case "3" -> updateTourist();
                case "4" -> recordInjury();
                case "5" -> viewInjuries();
                case "6" -> ReportsMenu.show();
                case "7" -> { System.out.println("Goodbye!"); return; }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    // === Register Tourist ===
    private static void registerTourist() {
        Tourist t = new Tourist();
        System.out.print("Enter Birth Code: ");
        t.setBirthCode(sc.nextLine());
        System.out.print("Enter Full Name: ");
        t.setFullName(sc.nextLine());
        System.out.print("Enter Address: ");
        t.setAddress(sc.nextLine());
        System.out.print("Enter Contact: ");
        t.setContact(sc.nextLine());
        System.out.print("Enter Trail: ");
        t.setTrail(sc.nextLine());
        System.out.print("Enter Gender: ");
        t.setGender(sc.nextLine());
        t.setTimeIn(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        t.setTimeOut(null);

        try {
            dao.insertTourist(t);
            System.out.println("✅ Tourist registered successfully!");
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    // === View Tourists ===
    private static void viewTourists() {
        try {
            for (Tourist t : dao.getAllTourists()) {
                System.out.printf("%d | %s | %s | %s | %s | %s | %s | %s%n",
                        t.getTouristId(), t.getBirthCode(), t.getFullName(),
                        t.getAddress(), t.getContact(), t.getTrail(),
                        t.getGender(), t.getTimeIn());
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    // === Update Tourist ===
    private static void updateTourist() {
        Tourist t = new Tourist();
        System.out.print("Enter Birth Code to update: ");
        t.setBirthCode(sc.nextLine());
        System.out.print("Enter New Full Name: ");
        t.setFullName(sc.nextLine());
        System.out.print("Enter New Address: ");
        t.setAddress(sc.nextLine());
        System.out.print("Enter New Contact: ");
        t.setContact(sc.nextLine());
        System.out.print("Enter New Trail: ");
        t.setTrail(sc.nextLine());
        System.out.print("Enter New Gender: ");
        t.setGender(sc.nextLine());

        try {
            dao.updateTourist(t);
            System.out.println("✅ Tourist updated successfully!");
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    

    // === Record Injury ===
    private static void recordInjury() {
        InjuryReport ir = new InjuryReport();
        System.out.print("Enter Tourist ID: ");
        ir.setTouristId(Integer.parseInt(sc.nextLine()));
        System.out.print("Enter Injury Case: ");
        ir.setInjuryCase(sc.nextLine());
        ir.setInjuryDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

        try {
            injuryDao.insertInjury(ir);
            System.out.println("✅ Injury recorded successfully!");
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    // === View Injuries ===
    private static void viewInjuries() {
        try {
            for (InjuryReport ir : injuryDao.getAllInjuries()) {
                System.out.printf("%d | TouristID: %d | %s | %s%n",
                        ir.getInjuryId(), ir.getTouristId(),
                        ir.getInjuryCase(), ir.getInjuryDate());
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }
}
