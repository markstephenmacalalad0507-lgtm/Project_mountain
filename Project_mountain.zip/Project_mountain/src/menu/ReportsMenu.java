package menu;

import dao.TouristDAO;
import dao.InjuryDAO;
import model.InjuryReport;
import java.util.Scanner;

public class ReportsMenu {
    private static final Scanner sc = new Scanner(System.in);
    private static final TouristDAO touristDao = new TouristDAO();
    private static final InjuryDAO injuryDao = new InjuryDAO();

    public static void show() {
        while (true) {
            System.out.println("\n=== Reports Menu ===");
            System.out.println("1. Show Total Tourist Records");
            System.out.println("2. Show Tourist Records Per Day");
            System.out.println("3. Show Tourist Records Per Month");
            System.out.println("4. Show Tourist Records Per Year");
            System.out.println("5. Show Injury Reports");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choice: ");
            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> showTotalTourists();
                case "2" -> showTouristsPerDay();
                case "3" -> showTouristsPerMonth();
                case "4" -> showTouristsPerYear();
                case "5" -> showInjuries();
                case "6" -> { return; }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    // === Total Tourist Records ===
    private static void showTotalTourists() {
        try {
            int count = touristDao.countTourists();
            System.out.println("✅ Total tourists registered: " + count);
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    // === Records Per Day ===
    private static void showTouristsPerDay() {
        try {
            var records = touristDao.getTouristsPerDay();
            System.out.println("📊 Tourist Records Per Day:");
            for (var entry : records.entrySet()) {
                System.out.println(entry.getKey() + " : " + entry.getValue());
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    // === Records Per Month ===
    private static void showTouristsPerMonth() {
        try {
            var records = touristDao.getTouristsPerMonth();
            System.out.println("📊 Tourist Records Per Month:");
            for (var entry : records.entrySet()) {
                System.out.println(entry.getKey() + " : " + entry.getValue());
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    // === Records Per Year ===
    private static void showTouristsPerYear() {
        try {
            var records = touristDao.getTouristsPerYear();
            System.out.println("📊 Tourist Records Per Year:");
            for (var entry : records.entrySet()) {
                System.out.println(entry.getKey() + " : " + entry.getValue());
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    // === Injury Reports ===
    private static void showInjuries() {
        try {
            for (InjuryReport ir : injuryDao.getAllInjuries()) {
                System.out.printf("%d | TouristID: %d | %s | %s%n",
                        ir.getInjuryId(), ir.getTouristId(),
                        ir.getInjuryCase(), ir.getInjuryDate());
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }
}
