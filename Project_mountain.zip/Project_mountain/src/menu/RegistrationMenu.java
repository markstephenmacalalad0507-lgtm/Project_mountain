package menu;

public class RegistrationMenu {

}
