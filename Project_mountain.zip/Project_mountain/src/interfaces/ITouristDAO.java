package interfaces;

import java.util.List;
import model.Tourist;

public interface ITouristDAO {

    boolean addTourist(Tourist tourist);

    List<Tourist> getAllTourists();

    Tourist getTouristById(int touristId);

    boolean updateTourist(Tourist tourist);

    boolean deleteTourist(int touristId);
}