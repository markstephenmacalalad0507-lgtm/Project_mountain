package interfaces;

public class IInjuryDAO {

}
