package service;

import dao.TouristDAO;
import model.Tourist;

import java.sql.SQLException;
import java.util.List;

public class TouristService {

    private TouristDAO touristDAO;

    public TouristService() {
        touristDAO = new TouristDAO();
    }

    public void addTourist(Tourist tourist)
            throws SQLException {

        touristDAO.insertTourist(tourist);
    }

    public List<Tourist> getAllTourists()
            throws SQLException {

        return touristDAO.getAllTourists();
    }

    public void updateTourist(Tourist tourist)
            throws SQLException {

        touristDAO.updateTourist(tourist);
    }

    public void deleteTourist(int touristId)
            throws SQLException {

        touristDAO.deleteTourist(touristId);
    }

    public int getTotalTourists()
            throws SQLException {

        return touristDAO.countTourists();
    }
}