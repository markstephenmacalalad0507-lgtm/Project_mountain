package service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherService {

    public String getWeatherData() {

        try {

            String apiUrl =
                    "https://api.open-meteo.com/v1/forecast?" +
                    "latitude=13.9411&longitude=121.1631" +
                    "&current=temperature_2m,weather_code";

            URL url = new URL(apiUrl);

            HttpURLConnection conn =
                    (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("GET");

            BufferedReader reader =
                    new BufferedReader(
                            new InputStreamReader(
                                    conn.getInputStream()));

            StringBuilder response =
                    new StringBuilder();

            String line;

            while ((line = reader.readLine()) != null) {

                response.append(line);
            }

            reader.close();

            return response.toString();

        } catch (Exception e) {

            return "";
        }
    }

    public double getTemperature() {

        try {

            String weatherData =
                    getWeatherData();

            int currentIndex =
                    weatherData.indexOf("\"current\":");

            if (currentIndex == -1) {

                return 0;
            }

            String currentPart =
                    weatherData.substring(currentIndex);

            String searchKey =
                    "\"temperature_2m\":";

            int tempIndex =
                    currentPart.indexOf(searchKey);

            if (tempIndex == -1) {

                return 0;
            }

            tempIndex += searchKey.length();

            int commaIndex =
                    currentPart.indexOf(
                            ",",
                            tempIndex);

            int braceIndex =
                    currentPart.indexOf(
                            "}",
                            tempIndex);

            int endIndex;

            if (commaIndex != -1 &&
                    commaIndex < braceIndex) {

                endIndex = commaIndex;

            } else {

                endIndex = braceIndex;
            }

            String value =
                    currentPart.substring(
                            tempIndex,
                            endIndex)
                            .trim();

            return Double.parseDouble(value);

        } catch (Exception e) {

            return 0;
        }
    }

    public String getSafetyStatus(double temperature) {

        if (temperature >= 38) {

            return "EXTREME HEAT WARNING";
        }

        if (temperature >= 35) {

            return "HEAT WARNING";
        }

        if (temperature <= 15) {

            return "COLD WEATHER ALERT";
        }

        return "SAFE FOR HIKING";
    }

    public String getRecommendation(double temperature) {

        if (temperature >= 38) {

            return "Suspend hiking activities. Extreme temperature may cause heat exhaustion or heat stroke.";
        }

        if (temperature >= 35) {

            return "Advise hikers to hydrate regularly, take rest breaks, and avoid prolonged exposure to sunlight.";
        }

        if (temperature <= 15) {

            return "Advise hikers to wear warm clothing and monitor weather conditions closely.";
        }

        return "Weather conditions are suitable for hiking. Regular monitoring is still recommended.";
    }
}