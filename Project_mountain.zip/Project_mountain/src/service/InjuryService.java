package service;

public class InjuryService {

}
